# TP2
## Juego de la Vida
### Ingenieria Informatica, ITBA