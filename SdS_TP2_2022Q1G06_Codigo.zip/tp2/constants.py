nxC, nyC = 50, 50

centerX = nxC/2
centerY = nyC/2