nxC, nyC, nzC = 30, 30, 30

centerX = nxC/2
centerY = nyC/2
centerZ = nzC/2